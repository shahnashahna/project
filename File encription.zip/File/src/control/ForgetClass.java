package control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import support.DBConnection;

public class ForgetClass extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
	    try
	    {
	    	
    	 Connection connection=DBConnection.DBConnect();
    	 String folderpath="resources/pages/";
	    	 
	     if(request.getParameter("forget").equals("Update Password")){
	   	 
	   	 String username	=request.getParameter("username");
	   	 String password	=request.getParameter("password");
	   	 
		 String checksql="SELECT * FROM user_table WHERE username=?";
	     PreparedStatement ps=connection.prepareStatement(checksql);
	     ps.setString(1,username);

	     ResultSet rs=ps.executeQuery();
	     if (rs.next()){
	    	 System.out.println("password update...");
	    	 
	    	 String sql="Update user_table SET password='"+password+"' where username='"+username+"'";
	    	 System.out.println(sql);
	    	 PreparedStatement ps2=connection.prepareStatement(sql);
	    	 int i=ps2.executeUpdate();
	    	 String msg=(i>0)?"User Updated Password ...!":"Failed!! please tyr after some time";

	 	    request.setAttribute("msg",msg);
	 	    request.setAttribute("colour","green");
	 	    RequestDispatcher dispatcher = request.getRequestDispatcher(folderpath+"login.jsp");
	 	    connection.close();
	 	    dispatcher.forward(request, response);
	 	    
	   }else {
		   request.setAttribute("msg","User name and password not match with your databse...");
	  	   request.setAttribute("colour","red");
	  	   RequestDispatcher dispatcher = request.getRequestDispatcher(folderpath+"register.jsp");
	  	   connection.close();
	  	   dispatcher.forward(request, response);
	   }
	       
	     }	
	    }catch(Exception err){ err.printStackTrace(); }
	  }
	}