package control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import support.DBConnection;

public class GetPhoneClass extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
	    try
	    {
    	 Connection connection=DBConnection.DBConnect(); 
	   	 String username	=request.getParameter("username");
	   	String folderpath="resources/pages/";
	   	String key="-1";
	   	 
		 String checksql="SELECT * FROM user_table WHERE username=?";
	     PreparedStatement ps=connection.prepareStatement(checksql);
	     ps.setString(1,username);
	     ResultSet rs=ps.executeQuery();
	     if (rs.next()){
	    	 String phone=rs.getString("phone");
	    	 if(!phone.equals("")) {
	    		 key=phone;
	    	 }else {
	    		 
	    		 key="-1";
	    	 }
	   }else {
		   key="-2";
	   }	  
	     	request.setAttribute("phone",key);
	 	    RequestDispatcher dispatcher = request.getRequestDispatcher(folderpath+"phoneShow.jsp");
	 	    connection.close();
	 	    dispatcher.forward(request, response);
	   
	    }catch(Exception err){ err.printStackTrace(); }
	  }
	}