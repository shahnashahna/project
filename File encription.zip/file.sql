-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2018 at 11:48 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `file`
--

-- --------------------------------------------------------

--
-- Table structure for table `intruder_table`
--

CREATE TABLE `intruder_table` (
  `i_id` int(3) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `rec_id` varchar(50) NOT NULL,
  `file_id` int(3) NOT NULL,
  `status_msg` varchar(50) NOT NULL,
  `time` varchar(100) NOT NULL,
  `ipaddress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intruder_table`
--

INSERT INTO `intruder_table` (`i_id`, `user_id`, `rec_id`, `file_id`, `status_msg`, `time`, `ipaddress`) VALUES
(1, 'user1', 'user3', 12, 'puzzle not solved', 'Fri 2018.01.26 at 09:38:32 AM', '0:0:0:0:0:0:0:1'),
(2, 'user1', 'user2', 15, 'puzzle not solved', 'Fri 2018.01.26 at 09:40:47 AM', '0:0:0:0:0:0:0:1'),
(3, 'user1', 'user2', 15, 'puzzle not solved', 'Sun 2018.03.11 at 10:41:55 AM', '0:0:0:0:0:0:0:1'),
(4, 'user1', 'user2', 15, 'puzzle not solved', 'Sun 2018.03.11 at 10:44:23 AM', '0:0:0:0:0:0:0:1'),
(5, 'user2', 'user1', 4, 'puzzle not solved', 'Mon 2018.04.23 at 02:14:25 AM', '0:0:0:0:0:0:0:1'),
(6, 'user1', 'user3', 3, 'puzzle not solved', 'Mon 2018.04.23 at 03:08:20 AM', '0:0:0:0:0:0:0:1'),
(7, 'user1', 'user3', 3, 'puzzle not solved', 'Mon 2018.04.23 at 03:08:26 AM', '0:0:0:0:0:0:0:1'),
(8, 'user1', 'user2', 6, 'puzzle not solved', 'Mon 2018.04.23 at 03:10:01 AM', '0:0:0:0:0:0:0:1'),
(9, 'user1', 'user2', 6, 'puzzle not solved', 'Mon 2018.04.23 at 03:16:04 AM', '0:0:0:0:0:0:0:1');

-- --------------------------------------------------------

--
-- Table structure for table `user_file_table`
--

CREATE TABLE `user_file_table` (
  `f_id` int(3) NOT NULL,
  `user_id` int(3) NOT NULL,
  `receiver_id` int(3) NOT NULL,
  `file_key` varchar(300) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `date` varchar(60) NOT NULL,
  `status_msg` varchar(50) NOT NULL,
  `admin_key_status` varchar(1) NOT NULL,
  `level` varchar(1) NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_file_table`
--

INSERT INTO `user_file_table` (`f_id`, `user_id`, `receiver_id`, `file_key`, `filename`, `date`, `status_msg`, `admin_key_status`, `level`) VALUES
(1, 14, 13, 'ft9kmPvjGXyBBNWcXbZ8pQ==', '2.png', 'Sun 2018.03.11 at 10:39:09 AM', 'puzzle solved', 'Y', '2'),
(2, 14, 13, '8PCQOvJiRba7q7Wb/oFkgesEY8sxc9Bb4EyF5sRfY2g5cBOvL+NoVxi0KdzyFImZ', '3e8a81b5c5dc82bc956f62ff31e46d64 (1).jpg', 'Mon 2018.04.23 at 12:54:24 AM', 'puzzle solved', 'Y', '2'),
(3, 14, 15, '8946eL9CHkrSD1eG4pkyf0VRWL3TnmRTpkU1rgIN9KpaGry+8Pi2d4SzH0JEkE6K', '4bbe732e40dc496fe069474f688f9cf3.jpg', 'Mon 2018.04.23 at 12:59:39 AM', 'New File', 'N', '2'),
(4, 13, 14, 'gwhZ98leCrfvKOR0gPboeem0c7uFdgRLlt2EJW1nou8=', '4cMW8RIHtxQ35ZBCPKoAhafeMtc.jpg', 'Mon 2018.04.23 at 02:13:07 AM', 'New File', 'N', '2'),
(5, 13, 14, 'nxL5axeQTfSXeur2TQP/b7nknGCd9tF7yIFLzP5699BaGry+8Pi2d4SzH0JEkE6K', '5b5dea09ce97fc0daed27cef740f585e.jpg', 'Mon 2018.04.23 at 02:13:31 AM', 'New File', 'N', '2'),
(6, 14, 13, 'Cdwm6nPiWDrq6syl8QZjXQ==', '000_0035.jpg', 'Mon 2018.04.23 at 02:36:45 AM', 'New File', 'N', '3'),
(7, 13, 15, 'Cdwm6nPiWDrq6syl8QZjXQ==', '000_0035.jpg', 'Mon 2018.04.23 at 02:56:08 AM', 'New File', 'N', '2'),
(8, 13, 15, '8PCQOvJiRba7q7Wb/oFkgesEY8sxc9Bb4EyF5sRfY2haGry+8Pi2d4SzH0JEkE6K', '3e8a81b5c5dc82bc956f62ff31e46d64.jpg', 'Mon 2018.04.23 at 02:57:34 AM', 'New File', 'N', '4');

-- --------------------------------------------------------

--
-- Table structure for table `user_msg_table`
--

CREATE TABLE `user_msg_table` (
  `m_id` int(3) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `receiver_id` varchar(50) NOT NULL,
  `msg_key` varchar(300) NOT NULL,
  `msttitle` varchar(100) NOT NULL,
  `message` longtext NOT NULL,
  `date` varchar(60) NOT NULL,
  `status_msg` varchar(50) NOT NULL,
  `admin_key_status` varchar(1) NOT NULL,
  `level` varchar(1) NOT NULL DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_msg_table`
--

INSERT INTO `user_msg_table` (`m_id`, `user_id`, `receiver_id`, `msg_key`, `msttitle`, `message`, `date`, `status_msg`, `admin_key_status`, `level`) VALUES
(10, '14', '13', 'DjPJoktGqXU3G5fvejm3Wg==', 'hai', 'hai', 'Sun 2017.02.26 at 12:39:38 AM', 'puzzle solved', 'Y', '2'),
(11, '14', '15', 'DjPJoktGqXU3G5fvejm3Wg==', 'hai', 'this is message', 'Fri 2018.01.26 at 09:31:31 AM', 'puzzle solved', 'Y', '2'),
(12, '14', '15', 'DjPJoktGqXU3G5fvejm3Wg==', 'hai', 'this is message', 'Fri 2018.01.26 at 09:31:39 AM', 'New Message', 'N', '2'),
(13, '13', '15', 'ZsicWOgg2ipfCx31iqahwe9DF2fl2uMRzmEz/fMBOTE=', 'this msg beloges to user 3', 'sadf', 'Fri 2018.01.26 at 09:35:36 AM', 'New Message', 'N', '2'),
(14, '14', '15', 'MjjEJH/DBMXg8NRLwsQRiw==', 'asd', 'daa', 'Fri 2018.01.26 at 09:40:01 AM', 'New Message', 'N', '2'),
(15, '14', '13', 'MjjEJH/DBMXg8NRLwsQRiw==', 'asd', 'asd', 'Fri 2018.01.26 at 09:40:12 AM', 'puzzle solved', 'N', '2'),
(16, '13', '14', 'DjPJoktGqXU3G5fvejm3Wg==', 'hai', 'asd', 'Mon 2018.04.23 at 02:12:46 AM', 'New Message', 'N', '2'),
(17, '13', '15', 'h8BGI/tZj/zhk8A+HT4fjA==', 'sad', 's', 'Mon 2018.04.23 at 03:16:51 AM', 'New Message', 'N', '4');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(3) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `email` varchar(40) NOT NULL,
  `last_login` varchar(50) NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `password`, `phone`, `email`, `last_login`, `status`) VALUES
(6, 'admin', 'admin', '', 'admin@admin.com', 'Mon 2018.04.23 at 01:01:45 AM', 'Y'),
(13, 'user2', 'user2', '', 'user@gmai.com', 'Mon 2018.04.23 at 03:16:13 AM', 'Y'),
(14, 'user1', 'user1', '', 'user@gmai.com', 'Mon 2018.04.23 at 02:17:31 AM', 'Y'),
(15, 'user3', 'user3', '', 'user3@gmail.com', 'Mon 2018.04.23 at 03:17:02 AM', 'Y'),
(17, '123', '123', '', 'mailmydeveloper@gmail.com', 'Mon 2018.04.23 at 12:21:03 AM', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `intruder_table`
--
ALTER TABLE `intruder_table`
  ADD PRIMARY KEY (`i_id`);

--
-- Indexes for table `user_file_table`
--
ALTER TABLE `user_file_table`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `user_msg_table`
--
ALTER TABLE `user_msg_table`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `intruder_table`
--
ALTER TABLE `intruder_table`
  MODIFY `i_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user_file_table`
--
ALTER TABLE `user_file_table`
  MODIFY `f_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user_msg_table`
--
ALTER TABLE `user_msg_table`
  MODIFY `m_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
